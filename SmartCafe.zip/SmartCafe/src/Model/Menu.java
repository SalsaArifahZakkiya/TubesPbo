
package Model;

public abstract class Menu implements Inputable{
    private int IDMenu;
    private int Harga;
    private int item;
    private static int favorite;
    private static int JumlahTejual;
    private String[] ArrayFeedback;

    @Override
    public abstract void inputMenu();
    
    public void MenuFavorite(){
        Menu.favorite++;
    }
    public void JumlahTerjual(){
        Menu.JumlahTejual++;
    }
    /*
    public void LihatFeedback(){
        
    }
*/
    
}
