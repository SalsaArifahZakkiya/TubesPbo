
package Model;
import java.time.LocalDate;
import java.util.Scanner;
public class Pesanan {
    private int IDPesanan;
    private int[] IDMenu;
    private String NamaPemesan;
    private int[] NoMeja = {1,2,3,4,5,6,7,8,9,10};
    private String CatatanPesanan;
    private int JumlahPesanan;
    private String Feedback;
    private LocalDate TanggalPesanan;

    public Pesanan(int IDPesanan, int[] IDMenu, String NamaPemesan, int[] NoMeja, String CatatanPesanan, int JumlahPesanan, String Feedback, LocalDate TanggalPesanan) {
        this.IDPesanan = IDPesanan;
        this.IDMenu = IDMenu;
        this.NamaPemesan = NamaPemesan;
        this.NoMeja = NoMeja;
        this.CatatanPesanan = CatatanPesanan;
        this.JumlahPesanan = JumlahPesanan;
        this.Feedback = Feedback;
        this.TanggalPesanan = TanggalPesanan;
    }

    public int getIDPesanan() {
        return IDPesanan;
    }

    public int[] getIDMenu() {
        return IDMenu;
    }

    public String getNamaPemesan() {
        return NamaPemesan;
    }

    public int[] getNoMeja() {
        return NoMeja;
    }

    public String getCatatanPesanan() {
        return CatatanPesanan;
    }

    public int getJumlahPesanan() {
        return JumlahPesanan;
    }

    public String getFeedback() {
        return Feedback;
    }

    public LocalDate getTanggalPesanan() {
        return TanggalPesanan;
    }

    public void setIDPesanan(int IDPesanan) {
        this.IDPesanan = IDPesanan;
    }

    public void setIDMenu(int[] IDMenu) {
        this.IDMenu = IDMenu;
    }

    public void setNamaPemesan(String NamaPemesan) {
        this.NamaPemesan = NamaPemesan;
    }

    public void setNoMeja(int[] NoMeja) {
        this.NoMeja = NoMeja;
    }

    public void setCatatanPesanan(String CatatanPesanan) {
        this.CatatanPesanan = CatatanPesanan;
    }

    public void setJumlahPesanan(int JumlahPesanan) {
        this.JumlahPesanan = JumlahPesanan;
    }

    public void setFeedback(String Feedback) {
        this.Feedback = Feedback;
    }

    public void setTanggalPesanan(LocalDate TanggalPesanan) {
        this.TanggalPesanan = TanggalPesanan;
    }
    /*
    public void LihaFeedback(){
        
    }

    public int TotalPemesanan(){
        
    }
    
    public void JenisPesanan(){
        
    }
*/
    public void DataPemesanan(String NamaPemesan, int[] NoMeja, String CatatanPemesan){
        Scanner obj = new Scanner(System.in);
        System.out.println("Data Pemesanan :");
        
        System.out.println("Nama : ");
        this.NamaPemesan = obj.nextLine();
        
        System.out.println("No Meja : ");
        for(int i=0; i< NoMeja.length; i++){
            NoMeja[i] = obj.nextInt();
        }
        System.out.println("Catatan : ");
        this.CatatanPesanan = obj.nextLine();
       
    }
    public void tampilkanDataPemesanan(){
        System.out.println("Nama : " + this.NamaPemesan);
        System.out.println("No Meja : " + this.NoMeja);
        System.out.println("Catatan Pesana : " + this.CatatanPesanan);
    }
}
