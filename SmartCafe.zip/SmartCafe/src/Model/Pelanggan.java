
package Model;

public class Pelanggan extends UserLogin{
    private int NoMeja;
    private String Ruangan;
    private boolean StatusPesanan; 
    public Pelanggan(String Username, String Password, String Role, int NoMeja,String Ruangan, boolean StatusPesanan) {
        super(Username, Password, Role);
        this.NoMeja = NoMeja;
        this.Ruangan = Ruangan;
        this.StatusPesanan = StatusPesanan;
    }

    public Pelanggan(int NoMeja, String Ruangan, boolean StatusPesanan, String Username, String Password, String Role) {
        super(Username, Password, Role);
        this.NoMeja = NoMeja;
        this.Ruangan = Ruangan;
        this.StatusPesanan = StatusPesanan;
    }

    public int getNoMeja() {
        return NoMeja;
    }

    public String getRuangan() {
        return Ruangan;
    }

    public boolean getStatusPesanan() {
        return StatusPesanan;
    }
    
    public void MelakukanPemesanan(){
        
    } 
    
}
