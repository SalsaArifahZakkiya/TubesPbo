
package Model;

public interface Inputable {
   public abstract void inputMenu(); 
}
